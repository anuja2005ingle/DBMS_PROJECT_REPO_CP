import { createElement, useMemo, useState, type KeyboardEvent, type ReactNode } from "react";
import { domainData, projects, tagData, technologyData } from "./data/demoData";

type Page =
  | "home"
  | "discover"
  | "details"
  | "domains"
  | "technologies"
  | "tags"
  | "faculty"
  | "admin"
  | "admin-projects"
  | "project-form";
type Role = "Student" | "Faculty" | "Admin";
type IconName =
  | "search"
  | "arrow"
  | "book"
  | "layers"
  | "filter"
  | "users"
  | "calendar"
  | "code"
  | "tag"
  | "grid"
  | "menu"
  | "x"
  | "check"
  | "archive"
  | "edit"
  | "plus"
  | "chevron"
  | "database"
  | "folder";

const paths: Record<Page, string> = {
  home: "/",
  discover: "/discover",
  details: "/projects/PRJ-2025-0142",
  domains: "/domains",
  technologies: "/technologies",
  tags: "/tags",
  faculty: "/faculty",
  admin: "/admin",
  "admin-projects": "/admin/projects",
  "project-form": "/admin/projects/new",
};

function Icon({ name, size = "md" }: { name: IconName; size?: "sm" | "md" | "lg" }) {
  const common = { fill: "none", stroke: "currentColor", strokeWidth: 1.8, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  const parts: Record<IconName, ReactNode> = {
    search: <><circle cx="11" cy="11" r="6.8" {...common}/><path d="m16 16 4 4" {...common}/></>,
    arrow: <><path d="M5 12h14M14 7l5 5-5 5" {...common}/></>,
    book: <><path d="M5 4.5h10.5A2.5 2.5 0 0 1 18 7v12H7a2 2 0 0 1-2-2V4.5Z" {...common}/><path d="M8 8h6M8 11h5M5 16.5A2.5 2.5 0 0 1 7.5 14H18" {...common}/></>,
    layers: <><path d="m12 3 9 5-9 5-9-5 9-5Z" {...common}/><path d="m4.5 12 7.5 4 7.5-4M4.5 16l7.5 4 7.5-4" {...common}/></>,
    filter: <><path d="M4 6h16M7 12h10M10 18h4" {...common}/></>,
    users: <><circle cx="9" cy="9" r="3" {...common}/><path d="M3.5 20c.4-4 2.2-6 5.5-6s5.1 2 5.5 6M16 4.5a3 3 0 0 1 0 5.8M16.5 14c2.5.4 3.7 2.2 4 5" {...common}/></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2" {...common}/><path d="M8 3v4M16 3v4M3 10h18" {...common}/></>,
    code: <><path d="m8 9-4 3 4 3M16 9l4 3-4 3M14 5l-4 14" {...common}/></>,
    tag: <><path d="M4 4h7l9 9-7 7-9-9V4Z" {...common}/><circle cx="8" cy="8" r="1" {...common}/></>,
    grid: <><rect x="3" y="3" width="7" height="7" rx="1" {...common}/><rect x="14" y="3" width="7" height="7" rx="1" {...common}/><rect x="3" y="14" width="7" height="7" rx="1" {...common}/><rect x="14" y="14" width="7" height="7" rx="1" {...common}/></>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16" {...common}/></>,
    x: <><path d="m6 6 12 12M18 6 6 18" {...common}/></>,
    check: <><path d="m5 12 4 4L19 6" {...common}/></>,
    archive: <><path d="M4 7h16v14H4V7ZM3 3h18v4H3V3ZM9 11h6" {...common}/></>,
    edit: <><path d="m14 5 5 5L9 20H4v-5L14 5ZM12 7l5 5" {...common}/></>,
    plus: <><path d="M12 5v14M5 12h14" {...common}/></>,
    chevron: <><path d="m9 6 6 6-6 6" {...common}/></>,
    database: <><ellipse cx="12" cy="5" rx="8" ry="3" {...common}/><path d="M4 5v7c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12v7c0 1.7 3.6 3 8 3s8-1.3 8-3v-7" {...common}/></>,
    folder: <><path d="M3 6h7l2 2h9v11H3V6Z" {...common}/></>,
  };
  return <svg className={`icon icon-${size}`} viewBox="0 0 24 24" aria-hidden="true">{parts[name]}</svg>;
}

function Text({ as = "body", children, className = "" }: { as?: "display" | "title" | "subtitle" | "body" | "label"; children: ReactNode; className?: string }) {
  const level = as === "display" ? 1 : as === "title" ? 2 : as === "subtitle" ? 3 : undefined;
  return <div className={`text-${as} ${className}`} role={level ? "heading" : undefined} aria-level={level}>{children}</div>;
}

function Button({ children, onClick, kind = "primary", icon, className = "" }: { children: ReactNode; onClick?: () => void; kind?: "primary" | "secondary" | "ghost" | "danger"; icon?: IconName; className?: string }) {
  const activate = (event: KeyboardEvent<HTMLDivElement>) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      onClick?.();
    }
  };
  return <div className={`button button-${kind} ${className}`} role="button" tabIndex={0} onClick={onClick} onKeyDown={activate}>{icon && <Icon name={icon} size="sm"/>}<span>{children}</span></div>;
}

function Input({ value, onChange, placeholder, label, icon, onEnter }: { value: string; onChange: (value: string) => void; placeholder: string; label: string; icon?: IconName; onEnter?: () => void }) {
  return <div className="input-shell">{icon && <Icon name={icon}/>} {createElement("input", {
    value,
    onChange: (event: React.ChangeEvent<HTMLInputElement>) => onChange(event.target.value),
    onKeyDown: (event: React.KeyboardEvent<HTMLInputElement>) => event.key === "Enter" && onEnter?.(),
    placeholder,
    "aria-label": label,
  })}</div>;
}

function Chip({ children, tone = "neutral", removable }: { children: ReactNode; tone?: "neutral" | "blue" | "teal" | "purple" | "status"; removable?: boolean }) {
  return <span className={`chip chip-${tone}`}>{children}{removable && <Icon name="x" size="sm"/>}</span>;
}

function StatusBadge({ status }: { status: string }) {
  return <span className={`status status-${status.toLowerCase()}`}><span className="status-dot"/>{status}</span>;
}

function Logo({ onClick }: { onClick: () => void }) {
  return <div className="logo" role="button" tabIndex={0} onClick={onClick}>
    <span className="logo-mark"><Icon name="book"/></span>
    <span>ProjectHub</span>
  </div>;
}

function Navbar({ page, role, onNavigate, onRole, mobileOpen, setMobileOpen }: { page: Page; role: Role; onNavigate: (page: Page) => void; onRole: (role: Role) => void; mobileOpen: boolean; setMobileOpen: (value: boolean) => void }) {
  const links: [string, Page][] = [["Discover", "discover"], ["Projects", "discover"], ["Domains", "domains"], ["Technologies", "technologies"], ["Tags", "tags"]];
  return <div className="nav-wrap">
    <div className="navbar">
      <Logo onClick={() => onNavigate("home")}/>
      <div className={`nav-links ${mobileOpen ? "is-open" : ""}`}>
        {links.map(([label, target]) => <div key={label} className={`nav-link ${page === target ? "active" : ""}`} role="button" tabIndex={0} onClick={() => { onNavigate(target); setMobileOpen(false); }}>{label}</div>)}
      </div>
      <div className="nav-actions">
        <div className="nav-search" role="button" tabIndex={0} onClick={() => onNavigate("discover")}><Icon name="search"/><span>Search</span></div>
        <div className="role-switcher" title="Preview role">
          <span className="avatar">{role.slice(0, 1)}</span>
          <div><span className="role-name">{role}</span><span className="role-campus">Engineering</span></div>
          <div className="role-options">
            {(["Student", "Faculty", "Admin"] as Role[]).map((item) => <div key={item} role="button" tabIndex={0} onClick={() => { onRole(item); if (item === "Admin") onNavigate("admin"); else if (item === "Faculty") onNavigate("faculty"); }}>{item} view</div>)}
          </div>
        </div>
        <div className="mobile-menu" role="button" tabIndex={0} aria-label="Toggle menu" onClick={() => setMobileOpen(!mobileOpen)}><Icon name={mobileOpen ? "x" : "menu"}/></div>
      </div>
    </div>
  </div>;
}

function ProjectCard({ project, onView }: { project: typeof projects[number]; onView: () => void }) {
  return <div className="project-card">
    <div className="card-top"><div className="project-id">{project.id}</div><StatusBadge status={project.status}/></div>
    <Text as="subtitle" className="project-title">{project.title}</Text>
    <Text className="muted card-description">{project.description}</Text>
    <div className="meta-row"><span><Icon name="calendar" size="sm"/>{project.year}</span><span><Icon name="folder" size="sm"/>{project.type}</span></div>
    <div className="taxonomy"><div><span className="taxonomy-label">Domains</span><span className="chip-row">{project.domains.map((item) => <Chip key={item} tone="blue">{item}</Chip>)}</span></div>
      <div><span className="taxonomy-label">Technologies</span><span className="chip-row">{project.technologies.slice(0, 3).map((item) => <Chip key={item} tone="teal">{item}</Chip>)}</span></div>
    </div>
    <div className="card-footer"><span className="match-note"><Icon name="check" size="sm"/> Structured match</span><Button kind="ghost" onClick={onView}>View details <Icon name="arrow" size="sm"/></Button></div>
  </div>;
}

function SearchBox({ value, setValue, onSearch, compact = false }: { value: string; setValue: (value: string) => void; onSearch: () => void; compact?: boolean }) {
  return <div className={`search-box ${compact ? "compact" : ""}`}>
    <Input value={value} onChange={setValue} placeholder={compact ? "Search by title, description, tag or domain..." : "Search projects, technologies, domains or tags..."} label="Search projects" icon="search" onEnter={onSearch}/>
    <Button onClick={onSearch}>Search Projects <Icon name="arrow" size="sm"/></Button>
  </div>;
}

function Home({ onNavigate, setQuery }: { onNavigate: (page: Page) => void; setQuery: (query: string) => void }) {
  const [value, setValue] = useState("");
  const search = () => { setQuery(value); onNavigate("discover"); };
  return <main>
    <section className="hero">
      <div className="hero-orb hero-orb-one"/><div className="hero-orb hero-orb-two"/>
      <div className="hero-inner">
        <div className="eyebrow"><span className="eyebrow-icon"><Icon name="database" size="sm"/></span> Your campus project archive</div>
        <Text as="display">Discover what your campus<br/>has already <span className="accent-text">built.</span></Text>
        <Text className="hero-copy">Search previous and proposed student projects by topic, domain, technology, tags, and more—all through structured project data.</Text>
        <SearchBox value={value} setValue={setValue} onSearch={search}/>
        <div className="suggestions"><span>Popular searches</span>{["Theft detection", "Smart agriculture", "IoT", "Healthcare"].map((item) => <div role="button" tabIndex={0} key={item} onClick={() => { setQuery(item); onNavigate("discover"); }}>{item}</div>)}</div>
        <div className="hero-proof"><div><strong>480+</strong><span>Student projects</span></div><div><strong>28</strong><span>Academic domains</span></div><div><strong>12</strong><span>Departments</span></div></div>
      </div>
    </section>

    <section className="section feature-section">
      <div className="section-heading centered"><span className="kicker">BUILT FOR DISCOVERY</span><Text as="title">Find related projects faster</Text><Text className="muted">A clear view of your college's academic work, organized using structured project information.</Text></div>
      <div className="feature-grid">
        {[
          ["search", "Structured Search", "Search titles, descriptions, tags, technologies, and domains stored in the catalogue."],
          ["filter", "Focused Filtering", "Narrow results by academic year, project type, department, domain, and status."],
          ["layers", "Project Taxonomy", "Explore work through consistent domains, technologies, and project tags."],
          ["archive", "Project History", "Understand what was proposed, completed, and archived across academic years."],
        ].map(([icon, title, copy], index) => <div className="feature-card" key={title}><span className={`feature-icon feature-${index}`}><Icon name={icon as IconName}/></span><Text as="subtitle">{title}</Text><Text className="muted">{copy}</Text></div>)}
      </div>
    </section>

    <section className="section projects-section">
      <div className="section-heading row"><div><span className="kicker">NEW TO THE CATALOGUE</span><Text as="title">Recently added projects</Text></div><Button kind="secondary" onClick={() => onNavigate("discover")}>Browse all projects <Icon name="arrow" size="sm"/></Button></div>
      <div className="project-grid">{projects.slice(0, 3).map((project) => <ProjectCard key={project.id} project={project} onView={() => onNavigate("details")}/>)}</div>
    </section>

    <section className="section domain-preview">
      <div className="section-heading centered"><span className="kicker">BROWSE THE CATALOGUE</span><Text as="title">Explore by domain</Text><Text className="muted">Start with an area of interest and see the projects connected to it.</Text></div>
      <div className="domain-strip">{domainData.slice(0, 6).map(([name, count], index) => <div className="domain-mini" role="button" tabIndex={0} key={name} onClick={() => onNavigate("discover")}><span className={`domain-symbol domain-${index}`}><Icon name={["code", "layers", "users", "grid", "book", "database"][index] as IconName}/></span><span><strong>{name}</strong><small>{count} projects</small></span><Icon name="chevron" size="sm"/></div>)}</div>
      <div className="center-action"><Button kind="secondary" onClick={() => onNavigate("domains")}>View all domains</Button></div>
    </section>
  </main>;
}

function FilterPanel({ onClose, onApply }: { onClose?: () => void; onApply: () => void }) {
  return <aside className="filter-panel">
    <div className="filter-heading"><Text as="subtitle">Filters</Text>{onClose && <div role="button" tabIndex={0} onClick={onClose}><Icon name="x"/></div>}</div>
    {[
      ["Academic year", ["2025–26", "2024–25", "2023–24"]],
      ["Project type", ["EDI", "Capstone", "Major Project"]],
      ["Department", ["Computer Science", "Information Technology", "Electronics"]],
      ["Domain", ["Internet of Things", "Cybersecurity", "Energy", "Agriculture"]],
      ["Status", ["Active", "Proposed", "Completed"]],
    ].map(([label, values], section) => <div className="filter-group" key={label as string}><div className="filter-label">{label as string}</div>{(values as string[]).map((value, index) => <label className="check-row" key={value}>{createElement("input", { type: "checkbox", defaultChecked: (section === 0 && index === 0) || (section === 3 && index === 0) })}<span className="fake-check"><Icon name="check" size="sm"/></span><span>{value}</span><small>{[18, 12, 9][index] ?? 7}</small></label>)}</div>)}
    <div className="filter-actions"><Button onClick={onApply}>Apply filters</Button><Button kind="ghost">Clear all</Button></div>
  </aside>;
}

function Discover({ query, setQuery, onNavigate }: { query: string; setQuery: (query: string) => void; onNavigate: (page: Page) => void }) {
  const [draft, setDraft] = useState(query);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [showResults, setShowResults] = useState(query !== "none");
  const visible = useMemo(() => query.toLowerCase().includes("theft") ? projects.slice(0, 2) : projects, [query]);
  const apply = () => { setShowResults(true); setFiltersOpen(false); };
  return <main className="page-shell">
    <div className="page-head discover-head"><div><div className="breadcrumbs">Home <Icon name="chevron" size="sm"/> Discover</div><Text as="title">Discover Projects</Text><Text className="muted">Search the college project catalogue using structured project information.</Text></div></div>
    <SearchBox compact value={draft} setValue={setDraft} onSearch={() => { setQuery(draft); setShowResults(true); }}/>
    <div className="mobile-filter-button"><Button kind="secondary" icon="filter" onClick={() => setFiltersOpen(true)}>Filters</Button></div>
    <div className="discover-layout">
      <div className={`filter-drawer ${filtersOpen ? "is-open" : ""}`}><FilterPanel onClose={() => setFiltersOpen(false)} onApply={apply}/></div>
      <div className="desktop-filters"><FilterPanel onApply={apply}/></div>
      <div className="results-area">
        <div className="active-filters"><span>Active filters:</span><Chip tone="blue" removable>2025–26</Chip><Chip tone="blue" removable>Internet of Things</Chip>{query && <Chip tone="purple" removable>Search: {query}</Chip>}</div>
        <div className="results-heading"><div><Text as="subtitle">{showResults ? `${visible.length * 4 + 2} projects found` : "No projects found"}</Text><Text className="muted small">Sorted by structured search relevance</Text></div><div className="sort-control">Sort: <strong>Best match</strong><Icon name="chevron" size="sm"/></div></div>
        {showResults ? <><div className="results-list">{visible.map((project, index) => <div className="result-wrap" key={project.id}>{index === 0 && query && <div className="relevance-bar"><span>Strong match</span><small>Matches title, 2 tags, and 1 domain</small></div>}<ProjectCard project={project} onView={() => onNavigate("details")}/></div>)}</div><div className="pagination"><Button kind="secondary">Previous</Button><span className="page-current">1</span><span>2</span><span>3</span><span>…</span><span>8</span><Button kind="secondary">Next</Button></div></> : <EmptyState onClear={() => { setQuery(""); setShowResults(true); }}/>}
      </div>
    </div>
  </main>;
}

function EmptyState({ onClear }: { onClear: () => void }) {
  return <div className="state-card"><span className="state-icon"><Icon name="search" size="lg"/></span><Text as="subtitle">No projects found</Text><Text className="muted">Try a different keyword or remove some filters to broaden your search.</Text><Button kind="secondary" onClick={onClear}>Clear search & filters</Button></div>;
}

function Details({ onNavigate }: { onNavigate: (page: Page) => void }) {
  const p = projects[0];
  return <main className="page-shell detail-page">
    <div className="breadcrumbs"><span role="button" tabIndex={0} onClick={() => onNavigate("discover")}>Discover</span><Icon name="chevron" size="sm"/> Projects <Icon name="chevron" size="sm"/> {p.title}</div>
    <div className="detail-header">
      <div><div className="detail-id">{p.id} <StatusBadge status={p.status}/></div><Text as="display">{p.title}</Text><Text className="detail-lead">{p.description}</Text><div className="detail-meta"><span><Icon name="calendar" size="sm"/><small>Academic year</small><strong>{p.year}</strong></span><span><Icon name="folder" size="sm"/><small>Project type</small><strong>{p.type}</strong></span><span><Icon name="book" size="sm"/><small>Department</small><strong>{p.department}</strong></span></div></div>
      <Button kind="secondary" icon="archive">Save project</Button>
    </div>
    <div className="detail-layout">
      <div className="detail-main">
        <section className="content-card"><Text as="subtitle">About this project</Text><Text className="prose">Electricity theft creates significant financial and operational challenges for power distribution networks. This project records consumption data from connected meters and applies predefined threshold rules to identify unusual usage patterns for further review.</Text><Text className="prose">The system combines low-cost sensors with a web dashboard for authorized operators. All alerts and meter readings are stored as structured records, allowing reliable monitoring and historical comparisons.</Text></section>
        <section className="content-card"><Text as="subtitle">Project taxonomy</Text><div className="taxonomy-detail"><div><span className="tax-icon blue"><Icon name="grid"/></span><div><strong>Domains</strong><small>Areas this project belongs to</small><span className="chip-row">{p.domains.map((x) => <Chip key={x} tone="blue">{x}</Chip>)}</span></div></div><div><span className="tax-icon teal"><Icon name="code"/></span><div><strong>Technologies</strong><small>Tools and platforms used</small><span className="chip-row">{p.technologies.map((x) => <Chip key={x} tone="teal">{x}</Chip>)}</span></div></div><div><span className="tax-icon purple"><Icon name="tag"/></span><div><strong>Tags</strong><small>Stored project attributes</small><span className="chip-row">{p.tags.map((x) => <Chip key={x} tone="purple">{x}</Chip>)}</span></div></div></div></section>
        <section className="content-card"><div className="section-heading row"><div><Text as="subtitle">Related projects</Text><Text className="muted small">Projects with shared domains, technologies, or tags.</Text></div><Button kind="ghost" onClick={() => onNavigate("discover")}>View all</Button></div><div className="related-list">{projects.slice(1, 3).map((item) => <div className="related-card" key={item.id} role="button" tabIndex={0} onClick={() => onNavigate("details")}><div><Text as="subtitle">{item.title}</Text><Text className="muted">{item.description}</Text><span className="chip-row">{item.domains.map((x) => <Chip key={x} tone="blue">{x}</Chip>)}</span></div><Icon name="arrow"/></div>)}</div></section>
      </div>
      <aside className="detail-side">
        <div className="content-card"><Text as="subtitle">Student team</Text>{p.team.map((name, index) => <div className="person" key={name}><span className={`avatar avatar-${index}`}>{name.split(" ").map((x) => x[0]).join("")}</span><div><strong>{name}</strong><small>Student · Computer Engineering</small></div></div>)}</div>
        <div className="content-card"><Text as="subtitle">Faculty mentor</Text><div className="person"><span className="avatar mentor">KR</span><div><strong>{p.mentor}</strong><small>Department of Computer Engineering</small></div></div></div>
        <div className="content-card project-facts"><Text as="subtitle">Project information</Text><div><span>Project ID</span><strong>{p.id}</strong></div><div><span>Academic year</span><strong>{p.year}</strong></div><div><span>Status</span><StatusBadge status={p.status}/></div><div><span>Last updated</span><strong>14 Feb 2026</strong></div></div>
      </aside>
    </div>
  </main>;
}

function Explore({ type, onNavigate }: { type: "domains" | "technologies" | "tags"; onNavigate: (page: Page) => void }) {
  const config = {
    domains: ["Explore Domains", "Browse projects by their academic and application area.", "28 domains · 486 projects"],
    technologies: ["Explore Technologies", "Find projects by the tools, platforms, and technologies they use.", "74 technologies in the catalogue"],
    tags: ["Explore Tags", "Browse descriptive project attributes maintained in the catalogue.", "112 project tags"],
  }[type];
  const [search, setSearch] = useState("");
  return <main className="page-shell explore-page">
    <div className="explore-hero"><div className="breadcrumbs">Home <Icon name="chevron" size="sm"/> {config[0]}</div><Text as="display">{config[0]}</Text><Text>{config[1]}</Text><span className="catalogue-count">{config[2]}</span></div>
    {type !== "domains" && <div className="explore-search"><Input value={search} onChange={setSearch} placeholder={`Search ${type}...`} label={`Search ${type}`} icon="search"/></div>}
    {type === "domains" && <div className="domain-grid">{domainData.map(([name, count, copy], index) => <div className="domain-card" role="button" tabIndex={0} key={name} onClick={() => onNavigate("discover")}><span className={`domain-symbol domain-${index % 6}`}><Icon name={["code", "layers", "users", "grid", "book", "database"][index % 6] as IconName}/></span><Text as="subtitle">{name}</Text><Text className="muted">{copy}</Text><div><strong>{count} projects</strong><span>Explore projects <Icon name="arrow" size="sm"/></span></div></div>)}</div>}
    {type === "technologies" && <div className="technology-grid">{technologyData.filter(([name]) => String(name).toLowerCase().includes(search.toLowerCase())).map(([name, count, letters], index) => <div className="technology-card" role="button" tabIndex={0} key={name} onClick={() => onNavigate("discover")}><span className={`tech-logo tech-${index}`}>{letters}</span><div><Text as="subtitle">{name}</Text><Text className="muted">{count} projects</Text></div><Icon name="chevron"/></div>)}</div>}
    {type === "tags" && <div className="tag-cloud">{tagData.filter(([name]) => String(name).toLowerCase().includes(search.toLowerCase())).map(([name, count], index) => <div className={`tag-card tag-${index % 4}`} role="button" tabIndex={0} key={name} onClick={() => onNavigate("discover")}><Icon name="tag"/><span><strong>{name}</strong><small>{count} projects</small></span><Icon name="arrow" size="sm"/></div>)}</div>}
  </main>;
}

function Faculty({ onNavigate }: { onNavigate: (page: Page) => void }) {
  return <main className="page-shell">
    <div className="page-head row"><div><span className="kicker">FACULTY WORKSPACE</span><Text as="title">Welcome back, Dr. Rao</Text><Text className="muted">Review your mentored projects and keep their information current.</Text></div><Button onClick={() => onNavigate("project-form")} icon="plus">Propose project</Button></div>
    <div className="stat-grid compact-stats">{[["8", "Mentored projects", "book"], ["3", "Active this year", "layers"], ["14", "Student members", "users"], ["2", "Awaiting updates", "calendar"]].map(([value, label, icon]) => <div className="stat-card" key={label}><span><Icon name={icon as IconName}/></span><div><strong>{value}</strong><small>{label}</small></div></div>)}</div>
    <div className="content-card table-card"><div className="section-heading row"><div><Text as="subtitle">Your mentored projects</Text><Text className="muted small">Projects where you are listed as a faculty mentor.</Text></div><Button kind="secondary" onClick={() => onNavigate("discover")}>View catalogue</Button></div><ProjectTable faculty onNavigate={onNavigate}/></div>
  </main>;
}

function AdminSidebar({ page, onNavigate }: { page: Page; onNavigate: (page: Page) => void }) {
  return <aside className="admin-sidebar"><div className="admin-label">ADMINISTRATION</div>{[["grid", "Overview", "admin"], ["book", "Projects", "admin-projects"], ["users", "People", "admin"], ["folder", "Departments", "admin"], ["layers", "Taxonomy", "admin"]].map(([icon, label, target]) => <div className={page === target ? "active" : ""} role="button" tabIndex={0} key={label} onClick={() => onNavigate(target as Page)}><Icon name={icon as IconName}/><span>{label}</span></div>)}</aside>;
}

function Admin({ page, onNavigate }: { page: Page; onNavigate: (page: Page) => void }) {
  return <main className="admin-shell"><AdminSidebar page={page} onNavigate={onNavigate}/><div className="admin-content">
    {page === "admin" ? <><div className="page-head row"><div><Text as="title">Repository overview</Text><Text className="muted">A concise view of the college project catalogue.</Text></div><Button icon="plus" onClick={() => onNavigate("project-form")}>Add project</Button></div>
      <div className="stat-grid">{[["486", "Total projects", "+38 this year", "book"], ["214", "Active projects", "44% of catalogue", "layers"], ["132", "Archived projects", "Preserved history", "archive"], ["28", "Domains", "112 tags", "grid"]].map(([value, label, note, icon]) => <div className="admin-stat" key={label}><span><Icon name={icon as IconName}/></span><small>{label}</small><strong>{value}</strong><em>{note}</em></div>)}</div>
      <div className="admin-grid"><div className="content-card"><div className="section-heading row"><Text as="subtitle">Projects by academic year</Text><span className="muted small">Last 5 years</span></div><div className="bar-chart">{[["2021–22", 48], ["2022–23", 65], ["2023–24", 72], ["2024–25", 86], ["2025–26", 100]].map(([label, size]) => <div key={label}><span>{label}</span><i><b className={`bar bar-${size}`}/></i><strong>{Math.round(Number(size) * 1.32)}</strong></div>)}</div></div>
      <div className="content-card"><Text as="subtitle">Catalogue status</Text><div className="donut-wrap"><div className="donut"><span><strong>486</strong><small>projects</small></span></div><div className="legend"><span><i className="dot active"/>Active <strong>214</strong></span><span><i className="dot complete"/>Completed <strong>140</strong></span><span><i className="dot archived"/>Archived <strong>132</strong></span></div></div></div></div>
      <div className="content-card table-card"><div className="section-heading row"><Text as="subtitle">Recently updated projects</Text><Button kind="ghost" onClick={() => onNavigate("admin-projects")}>Manage projects <Icon name="arrow" size="sm"/></Button></div><ProjectTable onNavigate={onNavigate}/></div></>
    : <><div className="page-head row"><div><Text as="title">Project management</Text><Text className="muted">Manage records, relationships, and project statuses.</Text></div><Button icon="plus" onClick={() => onNavigate("project-form")}>Add project</Button></div><div className="admin-toolbar"><Input value="" onChange={() => {}} placeholder="Search projects by title or ID..." label="Search projects" icon="search"/><Button kind="secondary" icon="filter">Filter</Button></div><div className="content-card table-card"><ProjectTable onNavigate={onNavigate}/><div className="table-footer"><span>Showing 1–4 of 486 projects</span><div className="pagination mini"><Button kind="secondary">Previous</Button><span className="page-current">1</span><span>2</span><Button kind="secondary">Next</Button></div></div></div></>}
  </div></main>;
}

function ProjectTable({ onNavigate, faculty = false }: { onNavigate: (page: Page) => void; faculty?: boolean }) {
  return <div className="table-scroll"><div className="data-table"><div className="table-row table-head"><span>Project</span><span>Academic year</span><span>Type</span><span>Status</span><span>{faculty ? "Students" : "Created"}</span><span>Actions</span></div>{projects.map((p, index) => <div className="table-row" key={p.id}><span><strong>{p.title}</strong><small>{p.id} · {p.department}</small></span><span>{p.year}</span><span>{p.type}</span><span><StatusBadge status={p.status}/></span><span>{faculty ? p.team.length : ["14 Feb 2026", "08 Feb 2026", "22 Jan 2026", "18 Dec 2025"][index]}</span><span className="table-actions"><Button kind="ghost" onClick={() => onNavigate("details")}>View</Button><Button kind="ghost" icon="edit" onClick={() => onNavigate("project-form")}>Edit</Button></span></div>)}</div></div>;
}

function ProjectForm({ onNavigate }: { onNavigate: (page: Page) => void }) {
  const [saved, setSaved] = useState(false);
  const fields = [["Project title", "Enter a clear, descriptive title"], ["Academic year", "2025–26"], ["Project type", "Select project type"], ["Department", "Select department"]];
  return <main className="admin-shell"><AdminSidebar page="admin-projects" onNavigate={onNavigate}/><div className="admin-content form-page">
    <div className="breadcrumbs"><span role="button" tabIndex={0} onClick={() => onNavigate("admin-projects")}>Projects</span><Icon name="chevron" size="sm"/> Add project</div>
    {saved && <div className="success-toast"><Icon name="check"/><div><strong>Project saved</strong><small>The project record was created successfully.</small></div><Icon name="x"/></div>}
    <div className="page-head"><Text as="title">Add a new project</Text><Text className="muted">Create the core record, then connect its team and taxonomy.</Text></div>
    <div className="form-layout"><div>
      <div className="content-card form-section"><div className="form-section-head"><span>1</span><div><Text as="subtitle">Basic information</Text><Text className="muted small">Required details used throughout the catalogue.</Text></div></div><div className="form-grid">{fields.map(([label, placeholder], index) => <label className={index === 0 ? "full-field" : ""} key={label}><span>{label} <em>*</em></span><Input value="" onChange={() => {}} placeholder={placeholder} label={label}/></label>)}<label className="full-field"><span>Project description <em>*</em></span>{createElement("textarea", { placeholder: "Describe the problem, approach, and intended outcome...", "aria-label": "Project description", rows: 5 })}<small>Use a concise summary that helps students understand the project.</small></label></div></div>
      <div className="content-card form-section"><div className="form-section-head"><span>2</span><div><Text as="subtitle">Taxonomy & relationships</Text><Text className="muted small">Connect the project to structured catalogue attributes.</Text></div></div><div className="form-grid">{[["Domains", "Select one or more domains"], ["Technologies", "Select technologies used"], ["Tags", "Select descriptive tags"], ["Student team", "Search and add students"]].map(([label, placeholder]) => <label key={label}><span>{label}</span><div className="select-shell">{placeholder}<Icon name="chevron" size="sm"/></div></label>)}</div></div>
    </div><aside className="form-aside"><div className="content-card"><Text as="subtitle">Record status</Text><label><span>Initial status</span><div className="select-shell">Proposed <Icon name="chevron" size="sm"/></div></label><div className="info-note"><Icon name="archive"/><span>Projects can be archived later without removing their academic history.</span></div></div><div className="form-actions"><Button onClick={() => setSaved(true)}>Save project</Button><Button kind="secondary" onClick={() => onNavigate("admin-projects")}>Cancel</Button></div></aside></div>
  </div></main>;
}

function Footer({ onNavigate }: { onNavigate: (page: Page) => void }) {
  return <footer><div className="footer-inner"><div><Logo onClick={() => onNavigate("home")}/><Text>Structured project discovery for our campus community.</Text></div><div className="footer-links"><span role="button" tabIndex={0} onClick={() => onNavigate("discover")}>Discover</span><span role="button" tabIndex={0} onClick={() => onNavigate("domains")}>Domains</span><span role="button" tabIndex={0} onClick={() => onNavigate("technologies")}>Technologies</span></div><div className="footer-note"><span>Demonstration data only</span><small>React interface · FastAPI ready · MySQL catalogue</small></div></div></footer>;
}

export default function App() {
  const [page, setPage] = useState<Page>("home");
  const [role, setRole] = useState<Role>("Student");
  const [query, setQuery] = useState("");
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = (next: Page) => {
    setPage(next);
    window.history.replaceState({}, "", paths[next]);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  return <div className="app">
    <Navbar page={page} role={role} onNavigate={navigate} onRole={setRole} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen}/>
    {page === "home" && <Home onNavigate={navigate} setQuery={setQuery}/>}
    {page === "discover" && <Discover query={query} setQuery={setQuery} onNavigate={navigate}/>}
    {page === "details" && <Details onNavigate={navigate}/>}
    {(page === "domains" || page === "technologies" || page === "tags") && <Explore type={page} onNavigate={navigate}/>}
    {page === "faculty" && <Faculty onNavigate={navigate}/>}
    {(page === "admin" || page === "admin-projects") && <Admin page={page} onNavigate={navigate}/>}
    {page === "project-form" && <ProjectForm onNavigate={navigate}/>}
    {!page.startsWith("admin") && page !== "project-form" && <Footer onNavigate={navigate}/>}
  </div>;
}
