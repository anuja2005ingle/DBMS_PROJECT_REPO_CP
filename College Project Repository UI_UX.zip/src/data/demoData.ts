export type Project = {
  id: string;
  title: string;
  description: string;
  year: string;
  type: string;
  status: string;
  department: string;
  domains: string[];
  technologies: string[];
  tags: string[];
  team: string[];
  mentor: string;
};

// Synthetic catalogue records used only to present the interface before API integration.
export const projects: Project[] = [
  {
    id: "PRJ-2025-0142",
    title: "Power Theft Detection System",
    description: "A monitoring system that identifies abnormal electricity consumption and helps flag potential power theft across connected meters.",
    year: "2025–26",
    type: "EDI",
    status: "Active",
    department: "Computer Engineering",
    domains: ["Energy", "IoT"],
    technologies: ["Arduino", "Python", "MySQL"],
    tags: ["Electricity Theft", "Monitoring", "Smart Grid"],
    team: ["Aarav Shah", "Meera Iyer", "Dev Patel"],
    mentor: "Dr. Kavita Rao",
  },
  {
    id: "PRJ-2025-0097",
    title: "CCTV-Based Theft Detection",
    description: "A campus security project for detecting suspicious motion patterns in designated restricted areas using camera event data.",
    year: "2025–26",
    type: "Capstone",
    status: "Proposed",
    department: "Information Technology",
    domains: ["Cybersecurity", "Computer Vision"],
    technologies: ["Python", "OpenCV", "FastAPI"],
    tags: ["Theft Detection", "Security", "CCTV"],
    team: ["Sana Khan", "Rohan Nair"],
    mentor: "Prof. Nikhil Desai",
  },
  {
    id: "PRJ-2024-0176",
    title: "Smart Agriculture Monitoring",
    description: "A sensor-based platform that records soil moisture, local temperature, and crop conditions for small farms.",
    year: "2024–25",
    type: "Major Project",
    status: "Completed",
    department: "Electronics",
    domains: ["Agriculture", "IoT"],
    technologies: ["Raspberry Pi", "Sensors", "React"],
    tags: ["Monitoring", "Irrigation", "Automation"],
    team: ["Ishita Kulkarni", "Arjun Mehta"],
    mentor: "Dr. Preeti Joshi",
  },
  {
    id: "PRJ-2024-0118",
    title: "College Project Repository",
    description: "A relational catalogue for preserving academic project history and helping students discover related campus work.",
    year: "2024–25",
    type: "EDI",
    status: "Completed",
    department: "Computer Science",
    domains: ["Web Development", "Education"],
    technologies: ["React", "FastAPI", "MySQL"],
    tags: ["Repository", "Discovery", "Management"],
    team: ["Anaya Gupta", "Kabir Jain", "Neel Roy"],
    mentor: "Prof. Shreya Menon",
  },
];

export const domainData = [
  ["Internet of Things", "84", "Connected devices, sensors, and physical computing.", "IoT"],
  ["Cybersecurity", "61", "Secure systems, privacy, and threat monitoring.", "Cybersecurity"],
  ["Healthcare", "48", "Digital tools supporting care and wellness.", "Healthcare"],
  ["Agriculture", "37", "Technology for farms, crops, and food systems.", "Agriculture"],
  ["Education", "55", "Learning platforms and campus tools.", "Education"],
  ["Web Development", "92", "Modern web applications and services.", "Web Development"],
  ["Energy", "29", "Monitoring, efficiency, and sustainable power.", "Energy"],
  ["Finance", "31", "Payments, accounting, and financial access.", "Finance"],
] as const;

export const technologyData = [
  ["Python", 126, "PY"], ["React", 93, "RE"], ["MySQL", 88, "MY"], ["Java", 72, "JV"],
  ["Arduino", 54, "AR"], ["FastAPI", 42, "FA"], ["Raspberry Pi", 39, "RP"], ["C++", 35, "C+"],
] as const;

export const tagData = [
  ["Monitoring", 64], ["Automation", 58], ["Security", 47], ["Management", 45],
  ["Detection", 41], ["IoT", 39], ["Healthcare", 35], ["Agriculture", 29],
  ["Analytics", 28], ["Education", 26], ["Sustainability", 21], ["Accessibility", 18],
] as const;
