const API_BASE_URL = import.meta.env.VITE_API_URL ?? "http://127.0.0.1:8000";

export const apiRoutes = {
  health: () => `${API_BASE_URL}/health`,
  projects: () => `${API_BASE_URL}/projects/`,
  project: (projectId: string) => `${API_BASE_URL}/projects/${projectId}`,
  searchProjects: (keyword: string) =>
    `${API_BASE_URL}/projects/search?${new URLSearchParams({ keyword })}`,
  projectStatus: (projectId: string) => `${API_BASE_URL}/projects/${projectId}/status`,
  projectRelationship: (
    projectId: string,
    relationship: "tags" | "technologies" | "domains" | "students" | "mentors" | "departments",
  ) => `${API_BASE_URL}/projects/${projectId}/${relationship}`,
  domains: () => `${API_BASE_URL}/domains`,
  tags: () => `${API_BASE_URL}/tags`,
  technologies: () => `${API_BASE_URL}/technologies`,
  projectTypes: () => `${API_BASE_URL}/project-types`,
  projectStatuses: () => `${API_BASE_URL}/project-statuses`,
  departments: () => `${API_BASE_URL}/departments`,
};

export async function getJson<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, {
    ...init,
    headers: { "Content-Type": "application/json", ...init?.headers },
  });

  if (!response.ok) {
    throw new Error("The project service is currently unavailable.");
  }

  return response.json() as Promise<T>;
}
